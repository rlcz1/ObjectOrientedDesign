#include <iostream>
#include <cassert>
#include "list.h"
#include "vector.h"
#include "stack.h"
#include "queue.h"

int main() {
  return 0;
}
